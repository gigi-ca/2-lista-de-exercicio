#include <stdio.h>

int main() {
    int opcao;
    
    do {
    
    printf("Bem Vindo á Loja de Roupas FashionMix!\n");
        printf("Menu\n");
        printf("1 - Camisa\n");
        printf("2 - Calça\n");
        printf("3 - Casaco\n");
        printf("0 - Sair\n");
        printf("Escolha uma opção para consultar o valor:\n ");
        scanf("%d", &opcao);

    switch (opcao) {
    
    case 1:
            printf("Camisa: 50,00\n");
            break;
            
            case 2:
            printf("Calça: 90,00\n");
            break;
            
            case 3:
            printf("Casaco: 70,00\n");
            
            case 0:
            printf("Saindo. Obrigada pela preferência!");
            break;
            default:
            printf("Opçao inválida! Tente novamente.");
    }
            
    }while (opcao != 0);

    
    return 0;
}
    

 
            