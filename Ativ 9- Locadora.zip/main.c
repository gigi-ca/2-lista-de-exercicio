#include <stdio.h>

int main() {
    float filmes;
    
    
    do
    {
        for (int i = 0; i < 5; i++) {
        printf("Bem Vindo á Locadora Vídeo Boom!\n");
        printf("Digite a quantidade de filmes que deseja alugar: \n");
        scanf("%f", &filmes);
        printf("Obrigada pela preferência!\n");
        break;
     
        }    
    }while (filmes >=5);
    
    return 0;
}