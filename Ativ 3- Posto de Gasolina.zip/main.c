#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main() {

    int opcao;
    float litros, precoporlitro, total;

    do {
    printf("Bem-vindo ao Posto de Gasolina FuelMax!\n");
    printf("Com o que deseja abastecer seu automóvel?\n");
    printf("1 - Gasolina\n"); 
    printf("2 - Etanol\n");
    printf("3 - Diesel\n");
    printf("0 - Sair\n");
    printf("Escolha uma opção: ");
    scanf("%d", &opcao);

if (opcao == 0) {
    printf("Até logo!\n");
    break;
}

printf("Digite a quantidade de litros: ");
    scanf("%f", &litros);

    switch (opcao) {
        
    case 1:
    precoporlitro = 5.99;
    break;
    
    case 2:
    precoporlitro = 4.49;
    break;
    
    case 3:
    precoporlitro = 6.89;
    break;
    
    default:
    printf("Opção inválida! Tente novamente.\n");
    }
    
    total = litros * precoporlitro;
    printf("Total a pagar: R$ %.2f\n", total);
    
    } while (opcao != 0);

    return 0;
}

    
    