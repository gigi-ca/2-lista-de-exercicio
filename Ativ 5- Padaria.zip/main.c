#include <stdio.h>

struct Produto {
    char nome[50];
    int codigo;
    float preco;
}
;

int main() {
    
    printf("Bem Vindo á Padaria Delícia de Trigo!\n");
    struct Produto produtos[5] = {
    {"Pão Francês", 105, 0.50},
    {"Croassaint", 106, 11.00},
    {"Torta de Frango", 107, 12.50},
    {"Coxinha", 108, 10.50},
    {"Pão de Queijo", 109, 6.00}
    
    };

    printf("Produtos com preço maior do que R$ 10.00:\n");

    for (int i = 0; i < 5; i++) {
    if (produtos[i].preco > 10.00) {
    printf("Nome: %s\n", produtos[i].nome);
    printf("Código: %d\n", produtos[i].codigo);
    printf("Preço: R$ %.2f\n\n", produtos[i].preco);

  }
    
    }

    return 0;
}
