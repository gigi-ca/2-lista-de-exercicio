#include <stdio.h>

int main() {
    int ingressos, totalpontos = 0;

    do {
        printf("Bem Vindo ao CinePonto! Se desejar sair, digite 0. \n");
        printf("Digite a quantidade de ingressos comprados : ");
        scanf("%d", &ingressos);

        if (ingressos > 0) {
            totalpontos += ingressos * 5; 
            printf("Total de pontos acumulados: %d\n", totalpontos);
        }

    } while (ingressos != 0);

    printf("Cadastro encerrado. Total final de pontos: %d\n", totalpontos);
    return 0;
}
