#include <stdio.h>

int main() {
    float notas[7], media = 0;
    
   
    for(int i = 0; i < 7; i++) {
        printf("Digite uma nota de 0 á 10 referente ao atendimento da cafeteria Café com Letras: \n");
        scanf("%f", &notas[i]);
        media += notas[i];
    }

    media /= 7;

    
    printf("A média das notas foi: %.2f\n", media);

    if (media >= 8) {
        printf("A média do atendimento foi boa!\n");
    } else if (media >= 5) {
        printf("A média do atendimento foi razoável.\n");
    } else {
        printf("A média do atendimento foi ruim.\n");
    }

    return 0;
}

