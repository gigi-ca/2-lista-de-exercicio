#include <stdio.h>


struct Livro {
    char nome[100];
    int ano;
};

int main() {
    struct Livro livros[8];

    printf("Bem Vindo á Livraria Letras Vivas!\n");
    for (int i = 0; i < 8; i++) {
        printf("Digite o nome do livro %d: ", i + 1);
        scanf(" %[^\n]", livros[i].nome); 
        printf("Digite o ano de publicação: ");
        scanf("%d", &livros[i].ano);
    }

    printf("Livros publicados antes do ano 2000:\n");

    for (int i = 0; i < 8; i++) {
        if (livros[i].ano < 2000) {
       printf("%s - Ano: %d\n", livros[i].nome, livros[i].ano);
        
      }
        
    }

    return 0;
}
